import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:lastest_broo/controllers/auth_controller.dart';
import 'package:lastest_broo/controllers/notification_handler.dart';
import 'package:lastest_broo/firebase_options.dart';
import 'package:lastest_broo/view/adding.dart';
import 'package:lastest_broo/view/home.dart';
import 'package:lastest_broo/view/dashboard.dart';
import 'package:lastest_broo/view/login_page.dart';
import 'package:lastest_broo/view/logindreg_page.dart';
import 'package:lastest_broo/view/sell.dart';
import 'package:lastest_broo/view/web/webview.dart';
import 'package:lastest_broo/view/register_page.dart';
import 'package:lastest_broo/view/user_page.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
  );
  await Get.putAsync(() async => await SharedPreferences.getInstance());
  await FirebaseMessagingHandler().initPushNotification();
  await FirebaseMessagingHandler().initLocalNotification();

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  MyApp({super.key});
  final AuthController _authController = Get.put(AuthController());

  @override
  Widget build(BuildContext context) {
    return GetMaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        fontFamily: 'Montserrat',
        scaffoldBackgroundColor: const Color(0xffF5F3EF),
      ),
      initialRoute: _authController.isLoggedIn.value ? '/home' : '/user',
      getPages: [
        GetPage(name: '/home', page: () => HomePage()),
        GetPage(name: '/dashboard', page: () => Dashboard()),
        GetPage(name: '/adding', page: () => Adding()),
        GetPage(name: '/sell', page: () => SellPage()),
        GetPage(name: '/webViewPage', page: () => WebviewPage()),
        GetPage(name: '/login', page: () => LoginPage()),
        GetPage(name: '/register', page: () => RegisterPage()),
        GetPage(name: '/user', page: () => UserPage()),
        GetPage(name: '/logind', page: () => LoginDRegPage()),
      ],
    );
  }
}
